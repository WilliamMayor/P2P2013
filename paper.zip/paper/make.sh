pdflatex paper.tex > /dev/null
bibtex paper
pdflatex paper.tex > /dev/null
pdflatex paper.tex
