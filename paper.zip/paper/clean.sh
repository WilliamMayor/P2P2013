rm *.aux *.bbl *.blg *.log
